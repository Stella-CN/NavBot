"""Arrange actual CAD renders; no generated or retouched geometry."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json
root=Path(__file__).resolve().parents[1]
v=json.loads((root/'verification-summary.json').read_text())
bg=(240,245,251)
im=Image.new('RGB',(2400,1660),bg);d=ImageDraw.Draw(im)
font='/System/Library/Fonts/STHeiti Medium.ttc'
def txt(pos,text,size=30): d.text(pos,text,font=ImageFont.truetype(font,size),fill=(31,54,72))
txt((70,40),'NAVBOT / V16.5  上置电机 · 方案 A',52)
txt((70,115),'实际 CAD 装配预览  |  止口承托 + 侧向 M3 锁紧  |  无轮眉',28)
for name,x in [('CAD-exterior',30),('CAD-rear',1210)]:
 pic=Image.open(root/'参考图'/(name+'.png')).convert('RGB');pic.thumbnail((1160,1250))
 im.paste(pic,(x+(1160-pic.width)//2,190+(1250-pic.height)//2))
txt((75,178),'01  完整外观',28);txt((1250,178),'02  后侧平直面 · 下移充电口',28)
txt((70,1450),'整机约 222 × 261.5 × 254.2 mm（长 × 含轮宽 × 高）',32)
txt((70,1510),'9 件打印零件  ·  保留中央低位电池  ·  取消电机罩与轮眉',28)
txt((70,1570),'CAD 几何校核完成；尚未进行实体打印、负载及温升测试。',25)
im.save(root/'NavBot-V16.5-CAD-preview.png');im.save(root/'参考图/NavBot-V16.5-CAD-preview.png')
