from pathlib import Path
import vtk
from PIL import Image,ImageDraw,ImageFont
O=Path(__file__).resolve().parents[1];out=O/'参考图'
canvas=Image.new('RGB',(2000,800),(240,245,250));d=ImageDraw.Draw(canvas);font='/System/Library/Fonts/STHeiti Medium.ttc'
for i in range(2):
 r=vtk.vtkRenderer();r.SetBackground(240/255,245/255,250/255)
 for n,p,col in [('skin',O/'prototype-stl/HeadFront.stl',(.65,.76,.83)),('camera',O/'preview-mesh/D435_Official.stl',(.15,.19,.23))]:
  if n=='camera' and not i:continue
  rd=vtk.vtkSTLReader();rd.SetFileName(str(p));rd.Update();mesh=rd.GetOutput()
  if n=='skin':
   box=vtk.vtkPlane();box.SetOrigin(0,67.161,0);box.SetNormal(0,1,0)
   clip=vtk.vtkClipPolyData();clip.SetInputData(mesh);clip.SetClipFunction(box);clip.Update();mesh=clip.GetOutput()
  normals=vtk.vtkPolyDataNormals();normals.SetInputData(mesh);normals.SetFeatureAngle(45)
  mp=vtk.vtkPolyDataMapper();mp.SetInputConnection(normals.GetOutputPort());mp.ScalarVisibilityOff();a=vtk.vtkActor();a.SetMapper(mp);a.GetProperty().SetColor(col);a.GetProperty().SetAmbient(.3);a.GetProperty().SetDiffuse(.65);r.AddActor(a)
 cam=r.GetActiveCamera();cam.SetPosition(0,500,206.54);cam.SetFocalPoint(0,68,206.54);cam.SetViewUp(0,0,1);cam.ParallelProjectionOn();cam.SetParallelScale(35)
 w=vtk.vtkRenderWindow();w.SetOffScreenRendering(1);w.SetSize(1000,600);w.AddRenderer(r);w.SetMultiSamples(8);w.Render();r.ResetCameraClippingRange();w.Render()
 f=vtk.vtkWindowToImageFilter();f.SetInput(w);f.Update();wr=vtk.vtkPNGWriter();p=out/('_camera'+str(i)+'.png');wr.SetFileName(str(p));wr.SetInputConnection(f.GetOutputPort());wr.Write();w.Finalize();canvas.paste(Image.open(p),(i*1000,100));p.unlink()
 d.text((i*1000+40,45),'完整胶囊开口 · 前侧蒙皮剖层' if not i else '装入实际 D435 模型 · 正视贴合',font=ImageFont.truetype(font,30),fill=(30,55,70))
d.text((45,715),'可见开口 84.6 × 19.6 mm / R9.8；内侧随相机倒角渐扩；模型间隙约 0.25 mm，需打印试配。',font=ImageFont.truetype(font,26),fill=(30,55,70))
canvas.save(out/'D435-胶囊孔贴合.png')
