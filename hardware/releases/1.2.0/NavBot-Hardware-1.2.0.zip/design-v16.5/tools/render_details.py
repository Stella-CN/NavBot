from pathlib import Path
import sys,vtk
from PIL import Image,ImageDraw,ImageFont
O=Path(__file__).resolve().parents[1];P=O/'NavBot-V16.5-Print-Pack/STL';out=O/'参考图';out.mkdir(exist_ok=True)
canvas=Image.new('RGB',(2400,1000),(240,245,250));d=ImageDraw.Draw(canvas);font='/System/Library/Fonts/STHeiti Medium.ttc'
for i,(n,label,eye) in enumerate([('01_ChassisLower','01  底板锁紧座',(130,-190,150)),('05_C30D_RemovableTray','05  C30D 支撑座',(120,-180,150)),('07_HeadFront','07  屏幕安装支架',(80,-230,80))]):
 rd=vtk.vtkSTLReader();rd.SetFileName(str(P/(n+'.stl')));rd.Update();mesh=rd.GetOutput();b=mesh.GetBounds();c=[(b[j]+b[j+1])/2 for j in [0,2,4]]
 if i==2:c[2]=40
 norm=vtk.vtkPolyDataNormals();norm.SetInputData(mesh);norm.SetFeatureAngle(45);norm.SplittingOn()
 mp=vtk.vtkPolyDataMapper();mp.SetInputConnection(norm.GetOutputPort());a=vtk.vtkActor();a.SetMapper(mp);a.GetProperty().SetColor(.5,.65,.75);a.GetProperty().SetAmbient(.3)
 r=vtk.vtkRenderer();r.SetBackground(240/255,245/255,250/255);r.AddActor(a);cam=r.GetActiveCamera();cam.SetFocalPoint(*c);cam.SetPosition(*[x+y for x,y in zip(c,eye)]);cam.SetViewUp(0,0,1);cam.ParallelProjectionOn();cam.SetParallelScale([145,72,90][i])
 w=vtk.vtkRenderWindow();w.SetOffScreenRendering(1);w.SetSize(800,820);w.AddRenderer(r);w.Render();r.ResetCameraClippingRange();w.Render()
 f=vtk.vtkWindowToImageFilter();f.SetInput(w);f.Update();wr=vtk.vtkPNGWriter();tmp=out/('_detail'+str(i)+'.png');wr.SetFileName(str(tmp));wr.SetInputConnection(f.GetOutputPort());wr.Write();w.Finalize();canvas.paste(Image.open(tmp),(i*800,120));tmp.unlink()
 d.text((i*800+30,60),label,font=ImageFont.truetype(font,32),fill=(30,55,70))
canvas.save(out/(sys.argv[1] if len(sys.argv)>1 else 'V16.5-结构细节.png'))
