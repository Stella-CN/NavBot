"""Clean four shell ears inside the original cavity; preserve the external skin."""
from pathlib import Path
import json,math
import FreeCAD as A,Part
V=A.Vector

def refine_rear(shape):
    # Reconstruct untrimmed original inner loft. Its absent front segment is
    # the mirror of the rear segment; no exterior surface is approximated.
    faces={}
    floor=105.4797978092;top=239.5008386453
    for face in shape.Faces:
        if not isinstance(face.Surface,Part.BSplineSurface) or face.Area<2000:continue
        full=face.Surface.toShape();b=full.BoundBox
        if abs(b.ZMin-floor)>.001 or abs(b.ZMax-top)>.01:continue
        if b.XMax<0 and b.XMin>-86:continue
        if b.XMin>0 and b.XMax<86:continue
        faces.setdefault(round(full.ParameterRange[0]),full)
    assert set(faces)=={0,1,2,3,4,5,7},set(faces)
    mirror=A.Matrix();mirror.A22=-1
    faces[6]=faces[2].transformGeometry(mirror)
    walls=list(faces.values());caps=[]
    for z in [floor,top]:
        edges=[e for f in walls for e in f.Edges if e.BoundBox.ZLength<.001 and abs(e.BoundBox.ZMin-z)<.01]
        wire=Part.Wire(Part.__sortEdges__(edges));assert wire.isClosed()
        caps.append(Part.Face(wire))
    cavity=Part.makeSolid(Part.makeShell(walls+caps));cavity.fix(.0001,.0001,.001)
    if cavity.Volume<0:cavity.reverse()
    assert cavity.isValid() and len(cavity.Solids)==1
    axes=sorted({(round(f.Surface.Center.x,6),round(f.Surface.Center.z,9)) for f in shape.Faces if isinstance(f.Surface,Part.Cylinder) and abs(f.Surface.Radius-1.7)<1e-6 and abs(f.Surface.Axis.y)>.999})
    assert len(axes)==4
    result=shape.copy();zones=[]
    for x,z in axes:
        side=1 if x>0 else -1;inner=abs(x)-(10 if z<160 else 6.5)
        region=Part.makeBox(70,14,18,V(25 if side>0 else -95,40,max(floor,z-9)))
        zone=region.common(cavity);zones.append(zone)
        result=result.cut(zone)
        height=12 if z<160 else 11.6
        ear=Part.makeBox(85-inner,6.1,height,V(inner if side>0 else -85,47.26,z+6-height))
        ear=ear.makeFillet(2,[e for e in ear.Edges if e.BoundBox.YLength>6.099])
        result=result.fuse(ear.common(cavity))
        result=result.cut(Part.makeCylinder(1.7,8,V(x,46.5,z),V(0,1,0)))
        radius=5.8/math.sqrt(3)
        pts=[V(x+radius*math.cos(math.pi/6+i*math.pi/3),47.26,z+radius*math.sin(math.pi/6+i*math.pi/3)) for i in range(6)]
        result=result.cut(Part.Face(Part.makePolygon(pts+[pts[0]])).extrude(V(0,3.4,0)))
    result=result.removeSplitter()
    assert result.isValid() and len(result.Solids)==1
    # Coincident loft surfaces can yield invalid boolean slivers. Verify the
    # untouched external faces directly and test edited boundary samples.
    def outer_faces(s):
        return [f for f in s.Faces if
            (isinstance(f.Surface,Part.BSplineSurface) and
             abs(f.Surface.toShape().BoundBox.ZMin-102.7197978092)<.001) or
            (f.BoundBox.ZLength<.0001 and abs(f.BoundBox.ZMin-102.7197978092)<.001)]
    original_faces=outer_faces(shape);new_faces=outer_faces(result)
    assert len(original_faces)==len(new_faces)
    for f in original_faces:
        assert any(abs(f.Area-g.Area)<.001 and (f.CenterOfMass-g.CenterOfMass).Length<.0001 for g in new_faces)
    points=[v.Point for v in result.Vertexes]
    for e in result.Edges:
        b=e.BoundBox
        if b.YMin>39 and (b.ZMax<120 or b.ZMin>214):points.extend(e.discretize(Number=9))
    tested=0
    for point in points:
        if point.y<39 or not (point.z<120 or point.z>214):continue
        assert shape.isInside(point,.0001,True) or cavity.isInside(point,.0001,True),list(point)
        tested+=1
    return result,dict(axes_xz=axes,ear_thickness_mm=6.1,nut_AF_mm=5.8,nut_depth_mm=3.4,bearing_floor_mm=2.7,before_faces=len(shape.Faces),after_faces=len(result.Faces),external_faces_verified=len(original_faces),boundary_points_verified=tested,description='single continuous paddle; original external surfaces and four joint axes preserved')

if __name__=='__main__':
    root=Path(__file__).resolve().parents[1]
    doc=A.openDocument(str(root/'NavBot-V16.5.FCStd'))
    refined,report=refine_rear(doc.getObject('HeadRear').Shape)
    doc.getObject('HeadRear').Shape=refined;doc.recompute();doc.save()
    p=json.loads((root/'design-parameters.json').read_text());p['rear_ear_cleanup']=report
    (root/'design-parameters.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
    print(json.dumps(report,ensure_ascii=False),flush=True)
