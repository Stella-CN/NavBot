"""Compare the provided D435 mesh with the final front part in assembly space."""
from pathlib import Path
import json,math,hashlib
import vtk
O=Path(__file__).resolve().parents[1]
def read(p):
 r=vtk.vtkSTLReader();r.SetFileName(str(p));r.Update();return r.GetOutput()
front=read(O/'prototype-stl/HeadFront.stl');camera=read(O/'preview-mesh/D435_Official.stl')
implicit=vtk.vtkImplicitPolyDataDistance();implicit.SetInput(front)
sample=vtk.vtkSampleImplicitFunctionFilter();sample.SetInputData(camera);sample.SetImplicitFunction(implicit);sample.ComputeGradientsOff();sample.Update()
values=sample.GetOutput().GetPointData().GetArray('Implicit scalars')
assert values is not None
minimum=values.GetRange()[0];bad=[camera.GetPoint(i) for i in range(camera.GetNumberOfPoints()) if values.GetValue(i)<-.03]
print('CAMERA vertex distance min',minimum,'deep intersections',len(bad),bad[:8],flush=True)
assert not bad,'D435 mesh penetrates head front'
sections=[]
for y in [69.9198,69.75,69.5,69.25,69,68.75,68.5,68.25,68,67.75,67.5,67.25,67.16]:
 plane=vtk.vtkPlane();plane.SetOrigin(0,y,0);plane.SetNormal(0,1,0)
 cutter=vtk.vtkCutter();cutter.SetInputData(camera);cutter.SetCutFunction(plane);cutter.Update();q=cutter.GetOutput()
 points=[q.GetPoint(i) for i in range(q.GetNumberOfPoints())]
 radius=max(math.hypot(max(abs(x)-32.5,0),z-206.5397978092) for x,_,z in points)
 opening=(9.8+(69.921-y)/(.171)*.13) if y>=69.75 else (9.93+(69.75-y)/(69.75-67.159)*.67)
 gap=opening-radius;assert .2<gap<.4,(y,gap)
 sections.append({'y':y,'camera_radius':radius,'opening_radius':opening,'radial_gap':gap})
report={'assembly_sha256':hashlib.sha256((O/'NavBot-V16.5.FCStd').read_bytes()).hexdigest(),'mesh_vertices_checked':camera.GetNumberOfPoints(),'basis':'user supplied D435_Official mesh','front_opening':[84.6,19.6],'opening_center_z':206.5397978092,'minimum_sampled_vertex_signed_distance':minimum,'vertices_penetrating_over_003mm':len(bad),'sections':sections,'passed':True,'limitations':'Mesh-based check, not physical fit or optical field-of-view calibration.'}
(O/'camera-fit-verification.json').write_text(json.dumps(report,indent=2));print('CAMERA FIT VERIFIED',flush=True)
