"""Package only verified V16.5 outputs, with traceable parts and fasteners."""
from pathlib import Path
import csv,json,hashlib,shutil,zipfile
O=Path(__file__).resolve().parents[1];P=O/'NavBot-V16.5-Print-Pack'
v=json.loads((O/'verification-summary.json').read_text());e=json.loads((P/'导出校核.json').read_text());r=json.loads((P/'基准文件校核.json').read_text())
sha=hashlib.sha256((O/'NavBot-V16.5.FCStd').read_bytes()).hexdigest()
assert v['assembly_sha256']==r['assembly_sha256']==sha
assert v['unresolved_intersections']==0 and r['all_passed'] and len(e)==9
assert v['motor_cover_removed']
fit=json.loads((O/'camera-fit-verification.json').read_text());assert fit['passed'] and fit['assembly_sha256']==sha
expected={q['number']+'_'+q['object'] for q in e}
for folder,ext in [('STL','stl'),('STEP','step')]:assert {f.stem for f in (P/folder).glob('*.'+ext)}==expected
for f in (O/'参考图').glob('*.png'):shutil.copy2(f,P/'参考图'/f.name)
for n in ['checks.json','design-parameters.json','verification-summary.json','camera-fit-verification.json']:shutil.copy2(O/n,P/n)
rows=list(csv.DictReader((O.parent/'design-v16/NavBot-V16-Print-Pack/紧固连接清单.csv').open(encoding='utf-8-sig')))
rows=[q for q in rows if q['连接']!='11电机罩—底板']
for q in rows:
 if q['连接']=='底板—包围罩壳':q['说明']='方案A止口承托与侧向M3×10；内侧单面敞开六角槽AF5.8×4.2，直接横向插入螺母，无顶槽或后侧包裹壁。14mm宽、7.6mm厚完整座体，螺母与螺丝末端均内收。'
 if q['连接']=='金属电机支架—底板':q.update(螺丝='16 x M3x8 ISO7380-1',说明='金属支架下安装面Z22.800贴底板上表面，电机朝上；底板厚4，下侧Ø6.4×2.2头沉孔；螺母在金属支架上方。16套均建模，未修改金属孔位。')
 elif q['连接']=='05低位C30D托架—底板':q.update(连接='05低位C30D托架—12电池仓侧壁',说明='X±55，Y0；上方安装M3×10，05顶部Ø6.4×2头沉孔；电池仓宽根座7厚、下开AF5.8×5六角槽。螺母顶面Z60.200，支承面Z62.200。')
 elif q['连接']=='12下沉电池吊篮—底板':q.update(连接='12电池仓—底板',说明='X±55，Y±30；四个7mm厚外耳直接承托在底板上表面；底板Ø6.4×2.2头沉孔；耳板上开AF5.8×3.5六角槽，M3×8从下向上安装。')
 elif q['连接']=='充电线缆鞍座—压盖':q['说明']='后移紧凑夹持结构，轴线Z63，压盖中心Y-93.5、深11；螺母底面Z71.4。Ø12.4夹槽配软衬垫，需按实物母头尺寸确认。'
with (P/'紧固连接清单.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['连接','螺丝','螺母','说明']);w.writeheader();w.writerows(rows)
summary=[['M3×8 ISO7380-1',20],['M3×10 ISO7380-1',10],['M3×14 ISO7380-1',4],['M3×18 ISO7380-1',2],['M3×20 ISO7380-1',4],['M3×6 小头 D4.5 k2（C30D）',4],['M3×6（D435，配0.5垫片）',2],['M2.5×20（Jetson）',4],['M2×20（N10）',2],['M3（屏幕，长度待实测）',2],['M3六角螺母 AF5.5 厚2.4',40],['M3薄六角螺母 AF5.5 厚1.8',4],['M2.5六角螺母 AF5 厚2',4],['M2六角螺母 AF4 厚1.6',2]]
with (P/'紧固件采购汇总.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['规格','数量（未含备件）']);w.writerows(summary)
notes=f'''NavBot V16.5 — 上置电机 / 方案A / 无电机罩

本版变更
1. 四组MG513电机、金属支架及电机线束空间恢复V15上置朝向；轮胎、联轴器和输出轴位置不变。不修改任何金属零件的孔位或尺寸。
2. 删除V16的11号电机罩及其四套紧固件、底板安装孔和板下电机穿板槽。无轮眉。
3. 底板上表面Z22.800与金属支架实际下安装面相接；底板下表面Z18.800。
4. 四个外壳锁紧座采用单面敞开AF5.8×4.2六角凹槽，取消顶部投放槽和包裹壁。保留方案A：连续台阶承托、8mm搭接止口、单边0.6mm名义间隙、四颗前后侧向M3×10螺丝与防转六角螺母；锁紧承压面直接贴合。
5. 电池保持V16中心XY位置与低位Z19.2。底板开口扩大为94.4×81.4，容纳3mm厚电池仓壁并留0.6mm单边间隙。电池仓底部Z15.2，较底板下表面低3.6mm，形成小范围浅下沉；不是电机罩。
6. 电池仓侧壁及宽根斜撑承托05号C30D桥架，取消其原先与高位底板的连接。四个低位安装耳贴底板；两处上方座支承C30D。主板水平、XY与IMU居中均不变，承托面Z71.5。四个PCB支撑柱重新参数化为AF8.2下柱、收缩肩和Ø6承托面，清除旧梁残片及叠加凸环。
7. DC/DC移回后方中央（X0/Y-74），安装在底板一体支承条上，用软垫和两条扎带固定。电机仍处于同一底盘外壳内。
8. 充电口继续后方居中，接口轴线降至Z63，法兰顶部Z77完全处于后侧平直段；压盖中心移至Y-93.5、深度缩为11，避让后电机接线包络。开关位置不变。
9. 上盖向下延伸并重建四个下敞开侧向电机口；拆下四颗侧向螺丝后可向上移开外壳，不采用封闭轴孔套住电机。
10. 头部下方屏幕支架重建为两条连续支撑臂和过渡根部，清除历史凸台；两个屏幕孔轴、承托位置以及未涉及的头部结构不变。D435面板开口修复为84.6×19.6、两端R9.8的完整胶囊形，以实际相机前脸中心Z206.540对齐，前缘单边约0.25mm间隙，孔内侧渐扩到R10.6；仅补齐原2.76mm壁厚范围，未增加凸台或独立边框；相机、屏幕、Jetson、雷达位置保持。V15与V16工程不修改。

11. 头后壳四个连接耳清除历史叠层、薄边和台阶，整理为连续圆角耳板。保留原四孔轴、6.1mm厚度、AF5.8×3.4六角槽和2.7mm承压底；由原始内曲面限定清理范围，外曲面与底面逐面核对，原M3×20连接不变。上方两耳仍需要局部可拆支撑，非免支撑结构。

尺寸（mm，名义CAD值）
整机长×含轮宽×高：{v['overall_length_width_height'][0]:.2f} × {v['overall_length_width_height'][1]:.2f} × {v['overall_length_width_height'][2]:.2f}。
底板188×220×4；普通上盖顶面Z98.800，电机恢复上置后电器仓由V16净高35.6恢复为{v['electronics_clear_height']:.1f}；此值为底板至普通顶板内面的净高，不含板下电池浅下沉。
最低打印件离地{v['nominal_lowest_printed_z']:.1f}（电池仓底），未计轮胎压缩、地面不平。
电池顶面Z{v['battery_top_z']:.3f}，至C30D托架间隙{v['battery_to_carrier_gap']:.3f}。
电池仓至电机最小几何间隙{v['battery_to_motors_gap']:.3f}。

9件打印零件
01底板，02上盖，03充电口嵌件，04充电口压盖，05 C30D托架，07头前壳，08头后壳，09 Jetson托盘，12中央电池仓。
保留编号，06/10/11不存在，不要混用V16的底板、上盖、电池仓或05托架。

装配与维护
先装四组金属电机支架（M3×8从底部向上），再装电机/联轴器/85mm轮。
电池仓放入底板中央开口，用四颗M3×8从下向上固定其外耳。安装1mm软垫、电池和两条3.6mm宽扎带。
先把M3薄螺母装入05的PCB座并固定主板；把两颗普通M3螺母放入电池仓顶部支承座，再从05顶部拧入两颗M3×10。
DC/DC使用两条3.6mm扎带和1mm软垫；先确认接线方向与实际产品一致。
从座体内侧直接横向压入侧向螺母，安装带开关/充电口/头部的上盖，前后各两颗M3×10锁紧。
打开上盖时，先断开或释放头部/开关/充电线束，防止拉扯；取电池前先拆05托架及扎带。
仅原生设备螺纹处使用原生螺孔；所有新增打印结构均用通孔、金属螺丝和六角螺母，不使用自攻。

PETG FDM建议与未验证项
0.4mm喷嘴、0.2mm层高、4–5道外壁作为起始设置；承压座局部实心，实际切片以试件为准。
01底板平放，沉孔/扎带槽少量桥接需切片确认。02上盖考虑倒置支撑，曲面、颈座和电机侧开口不能宣称免支撑。
12电池仓底面朝平台；两个高位支承由约45度宽根斜撑承托；四个低位安装耳下方安排局部可拆支撑，区域外露便于清理，勿在六角槽内填难清除的支撑。
05低位桥架保持平放，底部螺母槽用可达支撑或桥接设置并试打；其他头部零件沿用V16打印方向要求。
01/02名义长度220，220平台需确认实际可打印范围；不可通过缩放整件解决平台边距问题。
螺母槽AF5.8、孔Ø3.4/3.5、止口0.6是首版配合值，先试打局部接合样件。

检查结果与边界
{v['checked_pairs']}组相关几何对已检查，无未解决干涉。4组原始电机接线包络与其自身电机相交，与V15原模型的交叠体积核对一致，不是装配冲突。
旧90×25相机矩形包络已移除，以用户提供的实际网格为准。D435实际模型13个截面与孔内渐扩轮廓对照通过；相机网格顶点检验无超过0.03mm穿入前脸塑料的顶点，未代替实物试配。相机下沿连续平面验算缺失体积为零，前脸三个截面均只有7个闭合轮廓（外边界、两个开窗、四个螺丝孔），无额外细缝。四处螺母内侧装入路径已检查，前脸安装孔轴与旧版一致。9件打印件均为有效单一实体；STL闭合，STEP已回读检查。继承曲面头壳出现体积积分差时以双向实体差集复核；网格体积近似误差限0.3%。
四电机6孔与原金属支架对齐；支架安装面接触校核通过；C30D底部额外0.5mm试移未触及05。
上盖去掉四颗侧向螺丝后在2/12/40mm抬升位置无实体冲突；这不是柔性线束仿真或完整连续运动学证明。
未做FEA、负载/振动/温升实测、切片路径或实体试打印。充电口仍为Ø12×26近似母头，实际线缆与接口方向需实物确认。

设计参考
Prusa：打印方向、悬空、倒角及公差试件。
https://help.prusa3d.com/article/modeling-with-3d-printing-in-mind_164135
Protolabs Network：定位止口、装配间隙、孔周承压座及加强筋。自攻建议未采用。
https://www.hubs.com/knowledge-base/enclosure-design-3d-printing-step-step-guide/
'''
(P/'设计与装配说明.txt').write_text(notes)
(O/'工程说明.txt').write_text('V16.5：电机和金属支架恢复底板上置，取消电机罩，保留方案A。\nNavBot-V16.5.FCStd为自包含装配；打印包内9件STL/STEP、图片、校核和紧固件清单。\n历史V15、V16不修改。重建脚本仍读取V15实际设备基准。\n')
files=sorted(f for f in P.rglob('*') if f.is_file() and f.name!='SHA256SUMS.txt')
(P/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+str(f.relative_to(P))+'\n' for f in files))
zpath=O/'NavBot-V16.5-Print-Pack.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,6) as z:
 for f in sorted(P.rglob('*')):
  if f.is_file():z.write(f,str(Path(P.name)/f.relative_to(P)))
with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
(O/'工程SHA256SUMS.txt').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name+'\n' for f in [O/'NavBot-V16.5.FCStd',zpath]))
print('PACKAGED',len(e),zpath.stat().st_size,flush=True)
