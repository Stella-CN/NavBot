"""Validate V16 BREP geometry, overlaps, native axes and export actual CAD meshes."""
from pathlib import Path
import FreeCAD as A,Part,MeshPart,Mesh
import json,hashlib,itertools
O=Path(__file__).resolve().parents[1];D=A.openDocument(str(O/'NavBot-V16.5.FCStd'))
P=O/'preview-mesh';P.mkdir(exist_ok=True)
objs={o.Name:o for o in D.Objects if hasattr(o,'Shape') and not o.Shape.isNull() and getattr(o,'Role','') in ['printed','actual','hardware','drawing_proxy','datasheet_proxy','reference','soft_pad']}
printed=[n for n,o in objs.items() if o.Role=='printed']
r={'sha256':hashlib.sha256((O/'NavBot-V16.5.FCStd').read_bytes()).hexdigest(),'solids':{},'intersections':[],'errors':[]}
for n in printed:
 s=objs[n].Shape;b=s.optimalBoundingBox(False)
 r['solids'][n]={'valid':s.isValid(),'count':len(s.Solids),'dimensions':[b.XLength,b.YLength,b.ZLength]}
changed={n for n in objs if n.startswith(('RF_','RB_','LF_','LB_'))}|{'HeadFront','ChassisLower','ChassisLid','C30D_RemovableTray','Battery_E351S','DCDC_12_19V_drawing','FrontSwitch_M12_drawing','ChargePort_Insert_D12_placeholder','ChargeCableClampCap'}|{n for n in objs if n.startswith(('MotorBase','BatteryDrop','ChargeMount','ChassisJoint','PCBTray'))}
bounds={n:o.Shape.optimalBoundingBox(False) for n,o in objs.items()}
pairs=set()
for a,b in itertools.combinations(objs,2):
 if (a in changed or b in changed) and bounds[a].intersect(bounds[b]):pairs.add((a,b))
for idx,(a,b) in enumerate(sorted(pairs)):
 if idx%20==0:print('PROGRESS',idx,len(pairs),a,b,flush=True)
 sa,sb=objs[a].Shape,objs[b].Shape
 try:
  if len(sb.Solids)>100:sa,sb=sb,sa
  if len(sa.Solids)>100:
   vol=sum(abs(s.common(sb).Volume) for s in sa.Solids if s.BoundBox.intersect(sb.BoundBox))
  else:vol=abs(sa.common(sb).Volume)
  if vol>.01:
   q={'a':a,'b':b,'volume':vol,'roles':[objs[a].Role,objs[b].Role]};r['intersections'].append(q);print('HIT',q,flush=True)
 except Exception as e:r['errors'].append([a,b,str(e)])
 r['last_pair']=[a,b]
 (O/'checks.json').write_text(json.dumps(r,indent=2))
r['tested_pairs']=len(pairs)
r['motor_axes']={}
for prefix in ['RF','RB','LF','LB']:
 sets=[]
 for suffix,radius in [('MG513',1.25),('SuppliedBracket_reference',1.6)]:
  pts=set()
  for f in objs[prefix+'_'+suffix].Shape.Faces:
   c=f.Surface
   if isinstance(c,Part.Cylinder) and abs(c.Radius-radius)<1e-6 and abs(c.Axis.x)>.999:pts.add((round(c.Center.y,5),round(c.Center.z,5)))
  sets.append(pts)
 r['motor_axes'][prefix]={'aligned':sets[0]==sets[1],'count':len(sets[0])}
scene=[]
for o in D.Objects:
 role=getattr(o,'Role','')
 if role not in ['printed','actual','hardware','drawing_proxy','datasheet_proxy','visual','soft_pad','actual_mesh']:continue
 if hasattr(o,'Mesh'):mesh=o.Mesh
 elif hasattr(o,'Shape'):mesh=MeshPart.meshFromShape(Shape=o.Shape,LinearDeflection=.1,AngularDeflection=.16,Relative=False)
 else:continue
 path=P/(o.Name+'.stl');mesh.write(str(path));scene.append({'name':o.Name,'role':role,'color':list(o.DisplayColor),'file':str(path)})
(P/'scene.json').write_text(json.dumps(scene,indent=2))
(O/'checks.json').write_text(json.dumps(r,indent=2));print('COMPLETE',len(pairs),len(r['intersections']),flush=True)
