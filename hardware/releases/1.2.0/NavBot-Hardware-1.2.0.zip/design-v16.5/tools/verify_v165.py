"""Final geometry, transform, fastener and assembly checks for V16."""
from pathlib import Path
import hashlib,json,math
import FreeCAD as A,Part
O=Path(__file__).resolve().parents[1];S=O.parent/'design-v15';V=A.Vector
D=A.openDocument(str(O/'NavBot-V16.5.FCStd'));B=A.openDocument(str(S/'NavBot-V15.FCStd'))
p=json.loads((O/'design-parameters.json').read_text());checks=json.loads((O/'checks.json').read_text())
assert checks['sha256']==hashlib.sha256((O/'NavBot-V16.5.FCStd').read_bytes()).hexdigest()
allowed={frozenset((a+'_MG513',a+'_MotorWireSpace')) for a in ['RF','RB','LF','LB']}
for row in checks['intersections']:
 if frozenset((row['a'],row['b'])) in allowed:
  expected=abs(B.getObject(row['a']).Shape.common(B.getObject(row['b']).Shape).Volume)
  assert abs(row['volume']-expected)<1e-5,(row,expected)

bad=[r for r in checks['intersections'] if frozenset((r['a'],r['b'])) not in allowed]
assert not bad and not checks['errors'],bad
assert all(v['valid'] and v['count']==1 for v in checks['solids'].values())
assert all(v['aligned'] and v['count']==6 for v in checks['motor_axes'].values())
changed={'HeadFront','HeadRear','ChassisLower','ChassisLid','C30D_RemovableTray','DCDC_LeadSpace'}|{o.Name for o in B.Objects if o.Name.startswith('Charge')}
verified={}
print('VERIFY rigid transforms',flush=True)
for o in B.Objects:
 if not hasattr(o,'Role') or o.Name in changed or o.Name in p['removed']:continue
 print('TRANSFORM',o.Name,flush=True)
 n=D.getObject(o.Name)
 if n is None:continue
 if hasattr(o,'Shape') and not o.Shape.isNull():
  q=o.Shape.copy();t=p['transforms'].get(o.Name,{})
  if 'rotation_x' in t:q.rotate(V(*t['center']),V(1,0,0),t['rotation_x'])
  if 'rotation_z' in t:q.rotate(V(*t.get('center',[0,0,0])),V(0,0,1),t['rotation_z'])
  if 'translation' in t:q.translate(V(*t['translation']))
  assert len(q.Vertexes)==len(n.Shape.Vertexes) and len(q.Faces)==len(n.Shape.Faces),o.Name
  err=max(((a.Point-b.Point).Length for a,b in zip(q.Vertexes,n.Shape.Vertexes)),default=0);assert err<1e-5,(o.Name,err)
  verified[o.Name]=err
 elif hasattr(o,'Mesh'):
  pa,fa=o.Mesh.Topology;pb,fb=n.Mesh.Topology;assert fa==fb
  delta=V(*p['transforms'].get(o.Name,{}).get('translation',[0,0,0]))
  err=max((a+delta-b).Length for a,b in zip(pa,pb));assert err<5e-5
  verified[o.Name]=err
print('VERIFY transforms complete',flush=True)
# Prior independently verified V2.1 IMU centering plus a pure vertical board shift.
assert p['transforms']['C30D_actual']['translation'][:2]==[0,0]
prior=json.loads((S/'c30d-centering-verification.json').read_text());assert prior['all_passed']
# Bottom components retain 0.5 mm space below the PCB after its relocation.
tray=D.getObject('C30D_RemovableTray').Shape;pcb=D.getObject('C30D_actual').Shape
vol=0
for solid in pcb.Solids:
 if solid.BoundBox.ZMin>=p['pcb_seat_z']-.001:continue
 q=solid.copy();q.translate(V(0,0,-.5));vol+=abs(q.common(tray).Volume)
assert vol<.001,('PCB underside clearance',vol)
print('VERIFY underside complete',flush=True)
# Fastener insertion corridors: 6 mm driver envelope from front/back exterior.
tool_checks=[]
for x in [-55,55]:
 for sign in [-1,1]:
  corridor=Part.makeCylinder(3,45,V(x,sign*111,p['base_top_z']+7),V(0,sign,0))
  for name in ['RF_Wheel','RB_Wheel','LF_Wheel','LB_Wheel','FrontSwitch_M12_drawing','ChargePort_Insert_D12_placeholder']:
   hit=abs(corridor.common(D.getObject(name).Shape).Volume);assert hit<.001,(x,sign,name)
  tool_checks.append([x,sign*111,p['base_top_z']+7])
# Interior-face nut loading must be free without relying on a top channel.
for i,sgn in enumerate([-1,-1,1,1],1):
 for travel in [0,1,3,8]:
  n=D.getObject('ChassisJointNut'+str(i)).Shape.copy();n.translate(V(0,-sgn*travel,0))
  assert abs(n.common(D.getObject('ChassisLower').Shape).Volume)<.001,('Nut insertion',i,travel)
def hole_axes(shape):
 result=set()
 for f in shape.Faces:
  c=f.Surface
  if isinstance(c,Part.Cylinder) and abs(c.Axis.y)>.999 and any(abs(c.Radius-r)<1e-5 for r in [1.7,3.2]):result.add((round(c.Center.x,4),round(c.Center.z,4),round(c.Radius,4)))
 return result
before=B.getObject('HeadFront').Shape.copy();before.translate(V(0,0,-p['head_drop_mm']))
assert hole_axes(before)==hole_axes(D.getObject('HeadFront').Shape),'Front mounting axes changed'
before=B.getObject('HeadRear').Shape.copy();before.translate(V(0,0,-p['head_drop_mm']))
assert hole_axes(before)==hole_axes(D.getObject('HeadRear').Shape),'Rear mounting axes changed'
assert p['rear_ear_cleanup']['external_faces_verified']>0
print('VERIFY nut insertion and front axes complete',flush=True)
# Rigid lift with the four side bolts removed; wiring slack requires physical confirmation.
stationary=['BatteryDropTray','ChassisLower','Battery_E351S','C30D_actual','C30D_RemovableTray','DCDC_12_19V_drawing']+[f'{a}_{b}' for a in ['RF','RB','LF','LB'] for b in ['MG513','SuppliedBracket_reference','Wheel']]
lifts=[]
for dz in [2,12,40]:
 print('VERIFY lift',dz,flush=True)
 for name in ['ChassisLid','ChargePort_Insert_D12_placeholder','ChargeCableClampCap','FrontSwitch_M12_drawing']:
  print('LIFT component',dz,name,flush=True)
  q=D.getObject(name).Shape.copy();q.translate(V(0,0,dz))
  for sn in stationary:
   s=D.getObject(sn).Shape
   if not q.optimalBoundingBox(False).intersect(s.optimalBoundingBox(False)):continue
   print('LIFT pair',dz,name,sn,flush=True)
   bb=s.optimalBoundingBox(False)
   clip=Part.makeBox(bb.XLength+.02,bb.YLength+.02,bb.ZLength+.02,V(bb.XMin-.01,bb.YMin-.01,bb.ZMin-.01))
   local=q.common(clip)
   if not local.Solids:continue
   hit=sum(abs(local.common(t).Volume) for t in s.Solids if local.BoundBox.intersect(t.BoundBox)) if len(s.Solids)>100 else abs(local.common(s).Volume)
   assert hit<.01,('Lift',dz,name,sn,hit)
 lifts.append(dz)
print('VERIFY lift complete',flush=True)
physical=[o for o in D.Objects if getattr(o,'Role','') in ['printed','actual','actual_mesh','hardware','drawing_proxy','datasheet_proxy','soft_pad']]
bb=A.BoundBox()
for o in physical:
 bb.add(o.Shape.optimalBoundingBox(False) if hasattr(o,'Shape') else o.Mesh.BoundBox)
base=D.getObject('ChassisLower').Shape.optimalBoundingBox(False);lid=D.getObject('ChassisLid').Shape.optimalBoundingBox(False)
r=dict(assembly_sha256=checks['sha256'],v15_source_unchanged=hashlib.sha256((S/'NavBot-V15.FCStd').read_bytes()).hexdigest()==p['source_sha256'],printed_count=len(checks['solids']),all_valid_single_solids=True,unresolved_intersections=0,checked_pairs=checks['tested_pairs'],inherited_reference_overlaps=len(checks['intersections']),rigid_transforms_verified=verified,imu_xy=prior['imu_xy'],board_rotation_unchanged=True,pcb_underside_extra_05mm_volume=vol,driver_corridors=tool_checks,rigid_lift_steps_mm=lifts,overall_length_width_height=[bb.YLength,bb.XLength,bb.ZLength],chassis_base_to_neck_height=lid.ZMax-base.ZMin,electronics_clear_height=p['roof_z']-3-p['base_top_z'],metal_bracket_ground_clearance=min(D.getObject(x+'_SuppliedBracket_reference').Shape.optimalBoundingBox(False).ZMin for x in ['RF','RB','LF','LB']),notes=['No FEA, slicer toolpath validation, load, thermal or print-fit test.','Assembly lifting assumes disconnected or sufficiently slack wiring.','DC jack remains an approximate D12 placeholder.'])
assert r['v15_source_unchanged']
v16=O.parent/'design-v16'
expected=(v16/'工程SHA256SUMS.txt').read_text().splitlines()[0].split()[0]
r['v16_source_unchanged']=hashlib.sha256((v16/'NavBot-V16.FCStd').read_bytes()).hexdigest()==expected
assert r['v16_source_unchanged']
r['battery_top_z']=D.getObject('Battery_E351S').Shape.optimalBoundingBox(False).ZMax
r['battery_to_carrier_gap']=D.getObject('Battery_E351S').Shape.distToShape(D.getObject('C30D_RemovableTray').Shape)[0]
assert D.getObject('MotorCover') is None
r['motor_cover_removed']=True
r['charging_axis_z']=p['charge_axis_z']
r['charge_flange_top_z']=p['charge_axis_z']+14
r['rear_corner_transition_z']=p['roof_z']-12
assert r['charge_flange_top_z']<r['rear_corner_transition_z']
r['charge_to_motor_wire_clearance']=min(D.getObject(a).Shape.distToShape(D.getObject(b+'_MotorWireSpace').Shape)[0] for a in ['ChargePort_Insert_D12_placeholder','ChargeCableClampCap'] for b in ['LB','RB'])
assert r['charge_to_motor_wire_clearance']>.5

r['nominal_lowest_printed_z']=min(D.getObject(n).Shape.optimalBoundingBox(False).ZMin for n in checks['solids'])
r['battery_to_motors_gap']=min(D.getObject('BatteryDropTray').Shape.distToShape(D.getObject(n+'_MG513').Shape)[0] for n in ['RF','RB','LF','LB'])
r['bracket_contacts']={}
for n in ['RF','RB','LF','LB']:
 b=D.getObject(n+'_SuppliedBracket_reference').Shape.copy();b.translate(V(0,0,-.01))
 area=abs(b.common(D.getObject('ChassisLower').Shape).Volume)/.01
 assert area>500,(n,area)
 r['bracket_contacts'][n]={'virtual_contact_area_mm2':area,'not_load_test':True}

(O/'verification-summary.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print('VERIFIED',r['overall_length_width_height'],r['chassis_base_to_neck_height'],flush=True)
