"""Reimport exported STEP/STL and compare against the current FreeCAD solids."""
from pathlib import Path
import FreeCAD as A,Part,Mesh
import hashlib,json
O=Path(__file__).resolve().parents[1];P=O/'NavBot-V16.5-Print-Pack';D=A.openDocument(str(O/'NavBot-V16.5.FCStd'))
rows=json.loads((P/'导出校核.json').read_text());result=[]
for r in rows:
 stem=r['number']+'_'+r['object'];cad=D.getObject(r['object']).Shape.copy();cad.translate(A.Vector(*r['translation']))
 step=Part.read(str(P/'STEP'/(stem+'.step')));mesh=Mesh.Mesh(str(P/'STL'/(stem+'.stl')))
 assert step.isValid() and len(step.Solids)==1 and mesh.isSolid(),stem
 error=abs(step.Volume-cad.Volume)/cad.Volume;me=abs(abs(mesh.Volume)-cad.Volume)/cad.Volume
 # STEP round-trip on inherited curved head surfaces changes integrated
 # volume by ~0.0019%; use 0.01% volume tolerance plus independent bounds.
 difference=None
 if error>=1e-4:
  # Curved BRep volume integration can differ after STEP serialization.
  # Require both directional boolean differences to be empty instead.
  difference=[abs(cad.cut(step).Volume),abs(step.cut(cad).Volume)]
  assert max(difference)<.01,(stem,error,difference)
 assert me<.003,(stem,me)
 bb=step.optimalBoundingBox(False);assert abs(bb.ZMin)<.001
 cb=cad.optimalBoundingBox(False)
 assert max(abs(a-b) for a,b in zip((bb.XLength,bb.YLength,bb.ZLength),(cb.XLength,cb.YLength,cb.ZLength)))<.02
 assert max(bb.XLength,bb.YLength)<=220.001
 result.append({'part':stem,'boolean_difference_mm3':difference,'step_valid':True,'mesh_closed':True,'step_relative_volume_error':error,'mesh_relative_volume_error':me})
report={'assembly_sha256':hashlib.sha256((O/'NavBot-V16.5.FCStd').read_bytes()).hexdigest(),'all_passed':True,'parts':result}
(P/'基准文件校核.json').write_text(json.dumps(report,indent=2));print('EXPORT VERIFIED',len(result),flush=True)
