"""Verify a rear-only edit and retain checks of unchanged other geometry."""
from pathlib import Path
import sys,json,hashlib
import FreeCAD as A,Part
O=Path(__file__).resolve().parents[1]
baseline=Path(sys.argv[1]);prior=json.loads(Path(sys.argv[2]).read_text())
assert hashlib.sha256(baseline.read_bytes()).hexdigest()==prior['assembly_sha256']
B=A.openDocument(str(baseline));D=A.openDocument(str(O/'NavBot-V16.5.FCStd'))
c=json.loads((O/'checks.json').read_text());p=json.loads((O/'design-parameters.json').read_text())
sha=hashlib.sha256((O/'NavBot-V16.5.FCStd').read_bytes()).hexdigest();assert sha==c['sha256']
assert prior['unresolved_intersections']==0 and not c['errors']
allowed={frozenset((a+'_MG513',a+'_MotorWireSpace')) for a in ['RF','RB','LF','LB']}
assert len(c['intersections'])==4
for r in c['intersections']:
    assert frozenset((r['a'],r['b'])) in allowed
    assert abs(abs(B.getObject(r['a']).Shape.common(B.getObject(r['b']).Shape).Volume)-r['volume'])<.0001
assert all(x['valid'] and x['count']==1 for x in c['solids'].values())
unchanged={}
assert {o.Name for o in B.Objects}=={o.Name for o in D.Objects}
for obj in B.Objects:
    if obj.Name=='HeadRear' or not hasattr(obj,'Role'):continue
    new=D.getObject(obj.Name)
    if hasattr(obj,'Shape') and not obj.Shape.isNull():
        raw=obj.Shape.exportBrepToString();other=new.Shape.exportBrepToString()
        if raw==other:
            unchanged[obj.Name]={'exact_brep_sha256':hashlib.sha256(raw.encode()).hexdigest()}
        else:
            a=obj.Shape;b=new.Shape
            assert (len(a.Vertexes),len(a.Edges),len(a.Faces))==(len(b.Vertexes),len(b.Edges),len(b.Faces)),obj.Name
            deviation=max(((v.Point-w.Point).Length for v,w in zip(a.Vertexes,b.Vertexes)),default=0)
            areas=max((abs(f.Area-g.Area) for f,g in zip(a.Faces,b.Faces)),default=0)
            centers=max(((f.CenterOfMass-g.CenterOfMass).Length for f,g in zip(a.Faces,b.Faces)),default=0)
            assert deviation<1e-6 and areas<1e-4 and centers<1e-6,(obj.Name,deviation,areas,centers)
            assert [type(f.Surface).__name__ for f in a.Faces]==[type(f.Surface).__name__ for f in b.Faces]
            unchanged[obj.Name]={'max_vertex_deviation_mm':deviation,'max_face_area_error_mm2':areas,'max_face_center_deviation_mm':centers,'topology_and_surface_types_match':True}
    elif hasattr(obj,'Mesh'):
        assert obj.Mesh.Topology==new.Mesh.Topology,obj.Name
        unchanged[obj.Name]='identical mesh topology and vertices'
def axes(shape):
    return sorted({(round(f.Surface.Center.x,6),round(f.Surface.Center.z,6)) for f in shape.Faces if isinstance(f.Surface,Part.Cylinder) and abs(f.Surface.Radius-1.7)<1e-6 and abs(f.Surface.Axis.y)>.999})
assert axes(B.getObject('HeadRear').Shape)==axes(D.getObject('HeadRear').Shape)
before=B.getObject('HeadRear').Shape.optimalBoundingBox(False);after=D.getObject('HeadRear').Shape.optimalBoundingBox(False)
assert all(abs(getattr(before,k)-getattr(after,k))<.001 for k in ['XMin','XMax','YMin','YMax','ZMin','ZMax'])
assert p['rear_ear_cleanup']['external_faces_verified']>0
report=dict(prior)
report.update(assembly_sha256=sha,checked_pairs=c['tested_pairs'],inherited_reference_overlaps=4)
report['rigid_transforms_verified']=dict(prior['rigid_transforms_verified']);report['rigid_transforms_verified'].pop('HeadRear',None)
report['rear_only_update']={'baseline_verification':prior,'unchanged_geometry':unchanged,'rear_ear_checks':p['rear_ear_cleanup'],'preserved_checks':'chassis lifting, fastener insertion, purchased-part transforms and front geometry apply to unchanged geometry within 1e-6 mm (serialization rounding checked)'}
(O/'verification-summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('VERIFIED rear-only edit; unchanged objects',len(unchanged),flush=True)
