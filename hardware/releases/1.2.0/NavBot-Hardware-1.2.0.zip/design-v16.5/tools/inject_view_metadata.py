"""Persist visibility/materials using the installed FreeCAD GuiDocument schema.
Does not modify Document.xml or any shape/mesh entry. Avoids GUI/OpenGL startup.
"""
from pathlib import Path
import zipfile,xml.etree.ElementTree as E,struct,json,os,hashlib
O=Path(__file__).resolve().parents[1];p=O/'NavBot-V16.5.FCStd'
sample=Path('/Applications/FreeCAD.app/Contents/Resources/share/examples/PartDesignExample.FCStd')
with zipfile.ZipFile(sample) as z:material=bytearray(z.read('ShapeAppearance2'))
assert len(material)==40 and struct.unpack_from('<I',material)[0]==1
with zipfile.ZipFile(p) as z:data={n:z.read(n) for n in z.namelist() if n!='GuiDocument.xml' and not n.startswith(('V15Material_','V165Material_'))}
original_geometry_hashes={n:hashlib.sha256(b).hexdigest() for n,b in data.items()}
doc=E.fromstring(data['Document.xml']);types={n.get('name'):n.get('type') for n in doc.findall('./Objects/Object')}
root=E.Element('Document',SchemaVersion='1');vp=E.SubElement(root,'ViewProviderData');visible={'printed','actual','actual_mesh','hardware','drawing_proxy','datasheet_proxy','visual','soft_pad'}
for obj in doc.findall('./ObjectData/Object'):
 name=obj.get('name');props=obj.find('Properties');role=props.find("Property[@name='Role']/String");role=role.get('value') if role is not None else ''
 show=role in visible or types.get(name) in ['App::Part','App::DocumentObjectGroup']
 view=E.SubElement(vp,'ViewProvider',name=name,expanded='0',treeRank='-1');ps=E.SubElement(view,'Properties')
 pr=E.SubElement(ps,'Property',name='Visibility',type='App::PropertyBool',status='1');E.SubElement(pr,'Bool',value=str(show).lower())
 color=props.find("Property[@name='DisplayColor']/PropertyColor")
 if color is not None:
  number=int(color.get('value'));blob=bytearray(material);struct.pack_into('<I',blob,8,number);filename='V165Material_'+name;data[filename]=bytes(blob)
  pr=E.SubElement(ps,'Property',name='ShapeAppearance',type='App::PropertyMaterialList',status='9');E.SubElement(pr,'MaterialList',file=filename,version='3')
  # Mesh view providers retain the legacy color property in some releases.
  if types.get(name)=='Mesh::Feature':
   pr=E.SubElement(ps,'Property',name='ShapeColor',type='App::PropertyColor',status='9');E.SubElement(pr,'PropertyColor',value=str(number))
 ps.set('Count',str(len(ps)))
vp.set('Count',str(len(vp)));settings=json.loads((O/'view-settings.json').read_text());axis=' '.join(map(str,settings['camera_axis']));angle=settings['camera_angle']
E.SubElement(root,'Camera',settings=f'OrthographicCamera {{\n viewportMapping ADJUST_CAMERA\n position 450 650 400\n orientation {axis} {angle}\n nearDistance 50\n farDistance 2000\n aspectRatio 1\n focalDistance 833.201656\n height 360\n}}\n')
data['GuiDocument.xml']=E.tostring(root,encoding='utf-8',xml_declaration=True)
tmp=p.with_suffix('.tmp.FCStd')
with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,6) as z:
 for n,b in data.items():z.writestr(n,b)
with zipfile.ZipFile(tmp) as z:
 assert z.testzip() is None
 for n,digest in original_geometry_hashes.items():assert hashlib.sha256(z.read(n)).hexdigest()==digest
os.replace(tmp,p);print('Visibility/material metadata written; geometry entries unchanged')
