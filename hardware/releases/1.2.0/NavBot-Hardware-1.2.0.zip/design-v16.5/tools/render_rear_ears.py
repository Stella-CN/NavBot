import vtk,sys
from pathlib import Path
O=Path(__file__).resolve().parents[1]
p=str(O/'prototype-stl/HeadRear.stl')
rd=vtk.vtkSTLReader();rd.SetFileName(p);rd.Update();m=vtk.vtkPolyDataMapper();m.SetInputConnection(rd.GetOutputPort());a=vtk.vtkActor();a.SetMapper(m);a.GetProperty().SetColor(.55,.67,.75);a.GetProperty().SetAmbient(.25)
r=vtk.vtkRenderer();r.AddActor(a);r.SetBackground(.94,.96,.98);c=r.GetActiveCamera();c.SetFocalPoint(0,5,171);c.SetPosition(65,330,280);c.SetViewUp(0,0,1);c.ParallelProjectionOn();c.SetParallelScale(100)
w=vtk.vtkRenderWindow();w.SetOffScreenRendering(1);w.SetSize(1300,1200);w.AddRenderer(r);w.Render();r.ResetCameraClippingRange();w.Render();f=vtk.vtkWindowToImageFilter();f.SetInput(w);f.Update();wr=vtk.vtkPNGWriter();wr.SetInputConnection(f.GetOutputPort());wr.SetFileName(str(O/'参考图/08_HeadRear-耳板优化.png'));wr.Write();w.Finalize()
