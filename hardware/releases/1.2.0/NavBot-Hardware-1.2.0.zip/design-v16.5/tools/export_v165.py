"""Export V16 printing solids with rigid print-bed translations only."""
from pathlib import Path
import FreeCAD as A,MeshPart,Mesh
import json,csv
O=Path(__file__).resolve().parents[1];P=O/'NavBot-V16.5-Print-Pack'
D=A.openDocument(str(O/'NavBot-V16.5.FCStd'))
for sub in ['STL','STEP','参考图']:(P/sub).mkdir(parents=True,exist_ok=True)
(O/'prototype-stl').mkdir(exist_ok=True)
nums={'ChassisLower':'01','ChassisLid':'02','ChargePort_Insert_D12_placeholder':'03','ChargeCableClampCap':'04','C30D_RemovableTray':'05','HeadFront':'07','HeadRear':'08','Jetson_RemovableTray':'09','BatteryDropTray':'12'}
rows=[]
for n,num in sorted(nums.items(),key=lambda q:q[1]):
 s=D.getObject(n).Shape.copy();assert s.isValid() and len(s.Solids)==1,n
 b=s.optimalBoundingBox(False);m=MeshPart.meshFromShape(Shape=s,LinearDeflection=.08,AngularDeflection=.15,Relative=False);m.write(str(O/'prototype-stl'/(n+'.stl')))
 shift=A.Vector(-(b.XMin+b.XMax)/2,-(b.YMin+b.YMax)/2,-b.ZMin);s.translate(shift)
 stem=num+'_'+n;s.exportStep(str(P/'STEP'/(stem+'.step')))
 m=MeshPart.meshFromShape(Shape=s,LinearDeflection=.08,AngularDeflection=.15,Relative=False);path=P/'STL'/(stem+'.stl');m.write(str(path));test=Mesh.Mesh(str(path))
 assert test.isSolid(),n
 rows.append({'number':num,'object':n,'quantity':1,'dimensions':[b.XLength,b.YLength,b.ZLength],'translation':list(shift),'cad_valid':True,'solid_count':1,'mesh_closed':True,'triangles':test.CountFacets,'volume':s.Volume,'mesh_volume':test.Volume})
 print('EXPORTED',num,n,rows[-1]['dimensions'],flush=True)
(P/'导出校核.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
with (P/'零件清单.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['编号','对象','数量','X mm','Y mm','Z mm','材料'])
 for r in rows:w.writerow([r['number'],r['object'],1,*[round(v,2) for v in r['dimensions']],'PETG'])
