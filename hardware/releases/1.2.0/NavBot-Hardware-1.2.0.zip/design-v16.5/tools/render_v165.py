"""Render tessellated FreeCAD solids; no generated illustrative geometry."""
from pathlib import Path
import json,sys
import vtk
from PIL import Image,ImageDraw,ImageFont
O=Path(__file__).resolve().parents[1];scene=json.loads((O/'preview-mesh/scene.json').read_text());out=O/'参考图';out.mkdir(exist_ok=True)
def render(name,eye,focus,scale,mode='exterior'):
 if len(sys.argv)>1 and name not in sys.argv[1:]:return
 r=vtk.vtkRenderer();r.SetBackground(.94,.96,.98)
 for part in scene:
  n=part['name']
  if part['role'] not in ['printed','actual','hardware','drawing_proxy','datasheet_proxy','visual','soft_pad','actual_mesh']:continue
  
  if mode=='open' and n in ['HeadRear','ChassisLid']:continue
  if mode=='chassis' and not n.startswith(('RF_','RB_','LF_','LB_','Battery','Charge','C30D','DCDC','Switch','FrontSwitch','MotorBase','PCBTray','ChassisLower','BatteryDrop')):continue
  if mode=='joint' and n not in ['ChassisLower','ChassisLid','ChassisJointBolt4','ChassisJointNut4']:continue
  if mode=='battery' and not n.startswith(('ChassisLower','Battery','C30D','PCBTray')):continue
  if mode=='head' and (n.startswith(('RF_','RB_','LF_','LB_','Battery','Charge','C30D','DCDC','Switch','FrontSwitch','Chassis'))):continue
  rd=vtk.vtkSTLReader();rd.SetFileName(part['file']);rd.Update();mesh=rd.GetOutput()
  if mode in ['section','battery'] and n in ['HeadRear','HeadFront','FrontPanelFinish','ChassisLid','ChassisLower','BatteryDropTray']:
   plane=vtk.vtkPlane();plane.SetOrigin(0,0,0);plane.SetNormal(1,0,0)
   clip=vtk.vtkClipPolyData();clip.SetInputData(mesh);clip.SetClipFunction(plane);clip.InsideOutOn();clip.Update();mesh=clip.GetOutput()
  if mode=='joint' and n in ['ChassisLower','ChassisLid']:
   plane=vtk.vtkPlane();plane.SetOrigin(55,0,0);plane.SetNormal(1,0,0)
   clip=vtk.vtkClipPolyData();clip.SetInputData(mesh);clip.SetClipFunction(plane);clip.InsideOutOn();clip.Update();mesh=clip.GetOutput()
  normals=vtk.vtkPolyDataNormals();normals.SetInputData(mesh);normals.SetFeatureAngle(50);normals.SplittingOn()
  mapper=vtk.vtkPolyDataMapper();mapper.SetInputConnection(normals.GetOutputPort());actor=vtk.vtkActor();actor.SetMapper(mapper)
  col=part['color'][:3];actor.GetProperty().SetColor(col);actor.GetProperty().SetAmbient(.28);actor.GetProperty().SetDiffuse(.72);actor.GetProperty().SetSpecular(.12);actor.GetProperty().SetSpecularPower(18)
  if mode=='explode':
   if n.startswith('BatteryDrop') or n.startswith('BatterySoft') or n=='Battery_E351S':actor.SetPosition(0,0,-25)
   elif n=='ChassisLid' or n.startswith(('Head','Neck','Jetson','WiFi','N10','Screen','Camera','D435','Eye_','Optic_','FrontPanel','Charge','Switch','FrontSwitch')):actor.SetPosition(0,0,105)
  r.AddActor(actor)
 cam=r.GetActiveCamera();cam.SetPosition(*eye);cam.SetFocalPoint(*focus);cam.SetViewUp(0,0,1);cam.ParallelProjectionOn();cam.SetParallelScale(scale)
 win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetSize(1500,1500);win.AddRenderer(r);win.SetMultiSamples(8);win.Render();r.ResetCameraClippingRange();win.Render()
 filt=vtk.vtkWindowToImageFilter();filt.SetInput(win);filt.Update();writer=vtk.vtkPNGWriter();writer.SetFileName(str(out/(name+'.png')));writer.SetInputConnection(filt.GetOutputPort());writer.Write();win.Finalize()
 print(name,flush=True)
render('CAD-exterior',(450,650,400),(0,0,139),200)
render('CAD-rear',(-450,-650,400),(0,0,139),200)
render('CAD-open',(-450,-650,400),(0,0,139),200,'open')
render('CAD-chassis-layout',(-450,-650,440),(0,-8,60),185,'chassis')
render('CAD-side',(650,0,145),(0,0,137),175)

render('CAD-exploded',(450,650,400),(0,0,185),260,'explode')
render('CAD-section',(450,650,400),(0,0,139),200,'section')

render('CAD-battery-drop',(450,650,330),(0,0,50),135,'battery')

render('CAD-joint-section',(220,300,170),(55,104,30),25,'joint')
