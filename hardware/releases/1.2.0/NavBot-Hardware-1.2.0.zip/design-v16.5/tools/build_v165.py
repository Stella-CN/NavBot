"""V16.5: upright stock motor brackets, central low battery, lapped shell joint.
All dimensions in millimetres. Purchased geometry is transformed rigidly only.
"""
from pathlib import Path
import hashlib,json,math
import FreeCAD as A
import Part
V=A.Vector
O=Path(__file__).resolve().parents[1];S=O.parent/'design-v15'
D=A.openDocument(str(S/'NavBot-V15.FCStd'))
old={o.Name:o.Shape.copy() for o in D.Objects if hasattr(o,'Shape') and not o.Shape.isNull() and hasattr(o,'Role')}
report={'source_sha256':hashlib.sha256((S/'NavBot-V15.FCStd').read_bytes()).hexdigest(),'transforms':{},'removed':[]}
Z=18.7997978091967;T=Z+4;SEAM=T+3;SEAT=71.5;CARRIER=62.1997978091967;HEAD_DROP=12.0

def box(w,d,h,x=0,y=0,z=0):return Part.makeBox(w,d,h,V(x-w/2,y-d/2,z))
def rr(w,d,h,z,r,x=0,y=0):
 s=box(w,d,h,x,y,z)
 return s.makeFillet(r,[e for e in s.Edges if e.BoundBox.ZLength>h-.0001])
def hexagon(af,h,p,axis=V(0,0,1)):
 radius=af/math.sqrt(3)
 pts=[V(radius*math.cos(math.pi/6+i*math.pi/3),radius*math.sin(math.pi/6+i*math.pi/3),0) for i in range(6)]
 s=Part.Face(Part.makePolygon(pts+[pts[0]])).extrude(V(0,0,h));s.Placement=A.Placement(p,A.Rotation(V(0,0,1),axis));return s

def put(n,s,role='printed',color=None):
 s=s.removeSplitter();assert s.isValid() and len(s.Solids)==1,(n,'invalid',len(s.Solids))
 o=D.getObject(n)
 if o is None:
  o=D.addObject('PartDesign::Feature',n);o.addProperty('App::PropertyString','Role');o.addProperty('App::PropertyColor','DisplayColor')
 o.Shape=s;o.Role=role
 if color:o.DisplayColor=color
 print('PUT',n,len(s.Faces),round(s.Volume,1),flush=True)
 return o

def shift(n,dx=0,dy=0,dz=0):
 o=D.getObject(n)
 if hasattr(o,'Mesh'):
  s=o.Mesh.copy();s.translate(dx,dy,dz);o.Mesh=s
 else:
  s=o.Shape.copy();s.translate(V(dx,dy,dz));o.Shape=s
 report['transforms'][n]={'translation':[dx,dy,dz]}
def remove(n):
 if D.getObject(n):D.removeObject(n);report['removed'].append(n)

def bolt(n,p,axis,length=8):
 # Nominal ISO7380 button head envelope; threads omitted.
 s=Part.makeCylinder(1.5,length,p,axis).fuse(Part.makeCylinder(2.85,1.65,p-axis*1.65,axis))
 return put(n,s,'hardware',(.40,.43,.46))
def nut(n,p,axis=V(0,0,1),height=2.4):
 return put(n,hexagon(5.5,height,p,axis).cut(Part.makeCylinder(1.5,height,p,axis)),'hardware',(.48,.50,.52))

# Restore the supplied V15 motor/bracket orientation; output axes stay fixed.
base=rr(188,220,4,Z,24)
for i,(x,y) in enumerate([(x,y) for x in [-74,-50,50,74] for y in [-82,-52,52,82]],1):
 base=base.cut(Part.makeCylinder(1.75,6,V(x,y,Z-1))).cut(Part.makeCylinder(3.2,2.201,V(x,y,Z-.001)))
 bolt('MotorBaseBolt'+str(i),V(x,y,Z+2.2),V(0,0,1),8)
 nut('MotorBaseNut'+str(i),V(x,y,T+2))
# Continuous ledge carries shell load; inset lip locates it.
ledge=rr(188,220,3.01,T-.01,24).cut(rr(173.8,205.8,4,T-.1,16.9))
lip=rr(180.8,212.8,11.01,T-.01,20.4).cut(rr(173.8,205.8,12,T-.1,16.9))
# Bevel the locating lip upper edge for easy seating.
edges=[e for e in lip.Edges if abs(e.BoundBox.ZMin-(T+11))<1e-5 and e.BoundBox.ZLength<1e-5]
lip=lip.makeChamfer(.6,edges)
base=base.fuse(ledge).fuse(lip)
# Four top-loaded captive nuts, well clear of wheel and central service ports.
for i,(x,sgn) in enumerate([(x,s) for s in [-1,1] for x in [-55,55]],1):
 axis=V(0,-sgn,0);z=T+7
 boss=rr(14,7.6,14,T,2,x,sgn*101.0)
 base=base.fuse(boss)
 base=base.cut(Part.makeCylinder(1.7,20,V(x,sgn*114,z),axis))
 # One exposed interior face: press the nut straight into an open hex recess.
 # No top-fed slot, rear enclosure or roof covering the insertion path.
 base=base.cut(hexagon(5.8,4.201,V(x,sgn*97.199,z),V(0,sgn,0)))
 nut('ChassisJointNut'+str(i),V(x,sgn*101.4,z),axis)
 bolt('ChassisJointBolt'+str(i),V(x,sgn*107.8,z),axis,10)
 base=base.cut(box(16,12,20,x,sgn*110.8,SEAM))
# Central battery well lies between the front and rear motors. Its removable
# cradle is supported by the structural plate.
for n in list(old):
 if n.startswith(('BatteryBolt','BatteryNut','BatteryWashers','BatterySoftPad','DCDCBase','DCDCStrap')) or n=='BatteryTray_strap_slots':remove(n)
bat=old['Battery_E351S'].copy();bat.rotate(V(0,0,0),V(0,0,1),90)
bb=bat.optimalBoundingBox(False);move=V(-bb.Center.x,-bb.Center.y,19.2-bb.ZMin);bat.translate(move)
D.getObject('Battery_E351S').Shape=bat
report['transforms']['Battery_E351S']={'rotation_z':90,'translation':list(move)}
base=base.cut(rr(94.4,81.4,6,Z-1,5.6))
reinforcement=rr(100.4,87.4,2.01,T-.01,8.6).cut(rr(94.4,81.4,3,T-.1,5.6))
for side in [-1,1]:
 for yy in [-30,30]:reinforcement=reinforcement.cut(rr(19,15,4,T-.1,2.5,side*53,yy))
base=base.fuse(reinforcement).cut(rr(20,16,9,Z-1,2,0,43))
# A small bottom recess retains V16's low battery, with a tall, continuous
# battery cradle carrying the PCB bridge. No independent motor cover or pillars.
basket=rr(93.2,80.2,CARRIER-15.2,15.2,5).cut(rr(87.2,74.2,60,18.2,2))
basket=basket.cut(rr(20,8,12,CARRIER-10,2,0,40.1))
for i,x in enumerate([-22,22],1):
 basket=basket.cut(rr(4.8,84,1.2,15.2,.6,x,0))
 for y in [-40.1,40.1]:basket=basket.cut(box(4.8,2.4,50,x,y,15.2))
 put('BatterySoftPad'+str(i),box(14,62,1,x,0,18.2),'soft_pad',(.25,.28,.30))
for i,(side,y) in enumerate([(side,y) for side in [-1,1] for y in [-30,30]],1):
 x=side*55
 ear=rr(18,14,7,T,2,side*53,y)
 # Wide root rather than hanging ears: bracket stands on the plate upper face.
 basket=basket.fuse(ear)
 basket=basket.cut(Part.makeCylinder(1.7,9,V(x,y,T-1))).cut(hexagon(5.8,3.5,V(x,y,T+3.5)))
 base=base.cut(Part.makeCylinder(1.7,6,V(x,y,Z-1))).cut(Part.makeCylinder(3.2,2.201,V(x,y,Z-.001)))
 bolt('BatteryDropBolt'+str(i),V(x,y,Z+2.2),V(0,0,1),8)
 nut('BatteryDropNut'+str(i),V(x,y,T+3.5))
# PCB bridge seats grow directly from battery sidewalls with ~45-degree roots.
for side in [-1,1]:
 x=side*55
 ear=rr(18,16,7,CARRIER-7,2,side*53,0)
 points=[V(side*44,-8,CARRIER-25),V(side*62,-8,CARRIER-7),V(side*62,-8,CARRIER),V(side*44,-8,CARRIER)]
 basket=basket.fuse(ear).fuse(Part.Face(Part.makePolygon(points+[points[0]])).extrude(V(0,16,0)))
 basket=basket.cut(Part.makeCylinder(1.7,9,V(x,0,CARRIER-8))).cut(hexagon(5.8,5.01,V(x,0,CARRIER-7-.01)))
put('BatteryDropTray',basket,'printed',(.18,.30,.37))
report['battery_drop']={'floor_bottom':15.2,'floor_thickness':3,'battery_bottom':19.2,'wall':3,'opening':[94.4,81.4],'support':'four M3x8 base screws; cradle sidewalls support C30D bridge'}
# DC/DC returns between the two rear motors, below their wire connectors.
dc=old['DCDC_12_19V_drawing'].copy();bb=dc.optimalBoundingBox(False)
delta=V(-bb.Center.x,-74-bb.Center.y,T+4-bb.ZMin);dc.translate(delta)
D.getObject('DCDC_12_19V_drawing').Shape=dc
report['transforms']['DCDC_12_19V_drawing']={'translation':list(delta)}
# Front-facing leads escape into the gap behind the battery cradle.
D.getObject('DCDC_LeadSpace').Shape=box(46,11,17,0,-48.5,T+7)
for y in [-87,-61]:base=base.fuse(rr(58,5,3,T,1,0,y))
for y in [-95.5,-52.5]:base=base.fuse(rr(58,2,6,T,.6,0,y))
for x in [-18,18]:
 base=base.cut(rr(4.8,49,1.4,Z,.6,x,-74))
 for y in [-98.5,-49.5]:base=base.cut(rr(4.8,2.4,5,Z-.1,.6,x,y))
for i,y in enumerate([-87,-61],1):put('DCDCSoftPad'+str(i),box(56,5,1,0,y,T+3),'soft_pad',(.25,.28,.30))
# Low removable PCB carrier: underside nut access before mounting, no tall pillars.
axes=json.loads((S/'design-parameters.json').read_text())['c30d']['axes_xy']
frame=rr(83,62,2.5,CARRIER,3,-10.5,-2).cut(rr(65,44,4,CARRIER-.1,3,-10.5,-2))
for x,y in axes:
 # Parametric hex-column, tapered shoulder and small PCB bearing pad only.
 # The old clipped arms and stacked circular collar are not reused.
 lower=hexagon(8.2,SEAT-2.6-CARRIER,V(x,y,CARRIER))
 # Obtain the planar wire deterministically, independent of face ordering.
 radius=8.2/math.sqrt(3)
 pts=[V(x+radius*math.cos(math.pi/6+i*math.pi/3),y+radius*math.sin(math.pi/6+i*math.pi/3),SEAT-2.6) for i in range(6)]
 wire=Part.makePolygon(pts+[pts[0]])
 circle=Part.Wire([Part.makeCircle(3,V(x,y,SEAT-2))])
 shoulder=Part.makeLoft([wire,circle],True,False)
 cap=Part.makeCylinder(3,2,V(x,y,SEAT-2))
 end=-29 if y<0 else 25
 link=rr(8.2,abs(end-y)+8.2,2.5,CARRIER,1.5,x,(end+y)/2)
 frame=frame.fuse(lower).fuse(shoulder).fuse(cap).fuse(link)
 frame=frame.cut(hexagon(5.8,SEAT-2.6-CARRIER+.01,V(x,y,CARRIER-.01))).cut(Part.makeCylinder(1.7,12,V(x,y,CARRIER)))
for i,x in enumerate([-55,55],1):
 frame=frame.fuse(rr(12,16,6.5,CARRIER,2,x,0))
 frame=frame.fuse(box(14 if x<0 else 33,10,2.5,-50 if x<0 else 42,0,CARRIER))
 frame=frame.cut(Part.makeCylinder(1.7,8,V(x,0,CARRIER-1))).cut(Part.makeCylinder(3.2,2.001,V(x,0,CARRIER+4.5)))
 bolt('PCBTrayBolt'+str(i),V(x,0,CARRIER+4.5),V(0,0,-1),10)
 nut('PCBTrayNut'+str(i),V(x,0,CARRIER-4.4))
put('C30D_RemovableTray',frame)
for n in ['C30D_actual','C30D_TopWiring']+[f'C30D{k}{i}' for k in ['Bolt','Nut'] for i in range(1,5)]:shift(n,dz=SEAT-81.4)
# Lower the complete head rigidly, preserving every native head interface.
for obj in list(D.Objects):
 n=obj.Name
 if not hasattr(obj,'Role'):continue
 if n.startswith(('Head','Neck','Jetson','WiFi','N10','Screen','Camera','D435','Eye_','Optic_')) or n=='FrontPanelFinish':
  if hasattr(obj,'Shape') or hasattr(obj,'Mesh'):shift(n,dz=-HEAD_DROP)
from refine_rear_ears import refine_rear
rear, report['rear_ear_cleanup'] = refine_rear(D.getObject('HeadRear').Shape)
put('HeadRear', rear)
# Rebuild the two lower screen supports from clean profiles. Keep shell skin,
# screen axes, face mating plane and camera structure outside this bounded zone.
front=D.getObject('HeadFront').Shape.copy()
front=front.cut(box(70,40,54,0,47.16,105.4797978092))
def prism(points,vec):return Part.Face(Part.makePolygon(points+[points[0]])).extrude(vec)
for x in [-9.9539,17.011]:
 hole_z=147.6717956092;foot=-23 if x<0 else 23
 web=prism([V(foot-6,48.42,105.4797978092),V(foot+6,48.42,105.4797978092),V(x+6,48.42,hole_z-6),V(x-6,48.42,hole_z-6)],V(0,9.5,0))
 boss=box(12,9.5,12,x,53.17,hole_z-6)
 boss=boss.makeFillet(2,[e for e in boss.Edges if e.BoundBox.YLength>9.499 and abs(e.BoundBox.ZMax-(hole_z+6))<1e-6])
 heel=prism([V(foot-6,48.42,105.4797978092),V(foot-6,67.3,105.4797978092),V(foot-6,67.3,113.5),V(foot-6,57.92,113.5),V(foot-6,48.42,124.0)],V(12,0,0))
 profile=prism([V(foot-6,48.42,105.4797978092),V(foot+6,48.42,105.4797978092),V(x+6,48.42,hole_z-6),V(x-6,48.42,hole_z-6)],V(0,18.88,0))
 heel=heel.common(profile)
 front=front.fuse(web).fuse(boss).fuse(heel)
 front=front.cut(Part.makeCylinder(1.7,12,V(x,47.5,hole_z),V(0,1,0))).cut(Part.makeCylinder(3.2,2.2,V(x,48.42,hole_z),V(0,1,0)))
# Preserve the original screen envelope including its 0.4 mm fit clearance.
front=front.cut(box(70,12.8,48,0,63.92,113.6605366092))
for n in ['Screen_PlugSpace','Neck_CablePassage']:front=front.cut(D.getObject(n).Shape.common(box(70,40,54,0,47.16,105.4797978092)))
# Restore a uniform original-thickness planar skin around the D435 aperture.
# Restrict all additions and cuts to the 2.76 mm front skin, not the supports.
face=max((f for f in D.getObject('HeadFront').Shape.Faces if isinstance(f.Surface,Part.Plane) and abs(f.BoundBox.YMin-69.92)<1e-5 and f.BoundBox.YLength<1e-5),key=lambda f:f.Area)
skin=Part.Face(face.OuterWire).extrude(V(0,-2.76,0))
patch=skin.common(box(146,2.76,34,0,68.54,190.0))
cam_z=206.5397978092
# The measured official mesh has a ~84.1 x19.1 front bezel, not the full 90x25 body.
def capsule_wire(y,r):
 a=V(-32.5,y,cam_z-r);b=V(32.5,y,cam_z-r);c=V(32.5,y,cam_z+r);d=V(-32.5,y,cam_z+r)
 return Part.Wire([Part.makeLine(a,b),Part.Arc(b,V(32.5+r,y,cam_z),c).toShape(),Part.makeLine(c,d),Part.Arc(d,V(-32.5-r,y,cam_z),a).toShape()])
capsule=Part.makeLoft([capsule_wire(67.159,10.6),capsule_wire(69.75,9.93),capsule_wire(69.921,9.8)],True,True)
screen=box(123.8,2.762,78.8,0,68.54,113.6605366092)
patch=patch.cut(capsule).cut(screen)
front=front.fuse(patch).cut(capsule)
# Keep original shell-fastener holes that share the repaired front skin region.
native=D.getObject('HeadFront').Shape
zone=box(146,2.762,34,0,68.54,190)
for f in native.Faces:
 c=f.Surface
 if isinstance(c,Part.Cylinder) and abs(c.Axis.y)>.999 and any(abs(c.Radius-r)<1e-5 for r in [1.7,3.2]) and abs(c.Center.x)>35:
  mask=Part.makeCylinder(3.6,3,V(c.Center.x,67.1,c.Center.z),V(0,1,0)).common(zone)
  front=front.cut(mask.cut(native))

# Hidden housing clearance stops at the rear skin plane; it cannot enlarge the
# visible aperture or cut the camera's rear mounting faces.
front=front.cut(box(90.6,22.29,25.6,0,56.015,cam_z-12.8))
ring=Part.Face(capsule_wire(67.26,11.2)).extrude(V(0,2.56,0)).cut(capsule)
missing=abs(ring.cut(front).Volume)
assert missing<.001,('Capsule rim incomplete',missing)
web_test=box(96,2.56,3.2,0,68.54,192.5605366092)
web_missing=abs(web_test.cut(front).Volume)
assert web_missing<.001,('Front web slit',web_missing)
for yy in [68.0,69.0,69.919]:
 section=front.slice(V(0,1,0),yy)
 assert len(section)==7 and all(w.isClosed() for w in section),('Unexpected front void',yy,len(section))

report['camera_aperture']={'width':84.6,'height':19.6,'radius':9.8,'center_z':cam_z,'rear_radius':10.6,'front_skin_y':[67.16,69.92],'nominal_radial_clearance':.25,'witness_ring_missing_mm3':missing,'patch_only_original_wall':True,'solid_web_missing_mm3':web_missing,'front_section_wires':7,'basis':'provided D435_Official mesh front bezel, section-measured'}
put('HeadFront',front)
report['mount_cleanup']={'chassis_nut_access':'open interior face AF5.8 depth4.2, no top slot','pcb_posts':'AF8.2 hex lower column, conical transition, D6 bearing pad','screen_supports':'two continuous 12mm wide webs with tapered roots, legacy clipped pads removed'}
source=old['ChassisLid'].copy();source.translate(V(0,0,-HEAD_DROP));roof=110.7997978091967-HEAD_DROP
outer=rr(188,220,roof-SEAM,SEAM,24)
outer=outer.makeFillet(12,[e for e in outer.Edges if abs(e.BoundBox.ZMin-roof)<1e-5 and e.BoundBox.ZLength<1e-5])
inner=rr(182,214,roof-3-SEAM+1,SEAM-1,21)
inner=inner.makeFillet(9,[e for e in inner.Edges if abs(e.BoundBox.ZMin-(roof-3))<1e-5 and e.BoundBox.ZLength<1e-5])
lid=outer.cut(inner)
core=box(160,150,100,z=roof-3)
lid=lid.cut(core).fuse(source.common(core)).fuse(source.common(box(400,400,200,z=roof)))
# Raised continuous perimeter rib and four broad load paths above the wiring.
rib_z=92.2
ribs=rr(156,144,roof-1-rib_z,rib_z,12).cut(rr(148.8,136.8,8,rib_z-.1,8.4))
for x in [-62,62]:
 for y in [-22,22]:
  side=1 if x>0 else -1
  collar=Part.makeCylinder(6.5,roof-1-rib_z,V(x,y,rib_z))
  pts=[V(x,y-6.5,rib_z),V(x,y+6.5,rib_z),V(side*77.2,y+1.8,rib_z),V(side*77.2,y-1.8,rib_z)]
  ribs=ribs.fuse(collar).fuse(Part.Face(Part.makePolygon(pts+[pts[0]])).extrude(V(0,0,roof-1-rib_z)))
  region=Part.makeCylinder(3.5,30,V(x,y,rib_z))
  ribs=ribs.cut(region.cut(source))
lid=lid.fuse(ribs)
for i,(x,sgn) in enumerate([(x,s) for s in [-1,1] for x in [-55,55]],1):
 axis=V(0,-sgn,0);z=T+7
 collar=rr(14,5.2,11,SEAM,1,x,sgn*107.4)
 top_edges=[e for e in collar.Edges if abs(e.BoundBox.ZMin-(SEAM+11))<1e-5 and e.BoundBox.ZLength<1e-5]
 collar=collar.makeChamfer(1.5,top_edges)
 lid=lid.fuse(collar)
 lid=lid.cut(Part.makeCylinder(1.7,20,V(x,sgn*114,z),axis))
 lid=lid.cut(Part.makeCylinder(3.2,6.2,V(x,sgn*114,z),axis))
# Compact rear charging cassette, sized for the existing D12 placeholder.
# Its separate clamp cap remains serviceable; the old 40 mm flange is removed.
def front_plate(w,h,depth,y,z,r):
 q=rr(w,h,depth,0,r);q.Placement=A.Placement(V(0,y,z),A.Rotation(V(1,0,0),90));return q
flange=front_plate(40,28,4,-108,63,4)
saddle=rr(34,11,9.2,53.8,2,0,-93.5)
sleeve=Part.makeCylinder(9.2,31,V(0,-108,63),V(0,1,0)).common(box(40,40,20,0,-92.5,43))
saddle=saddle.fuse(sleeve).fuse(flange)
bore=Part.makeCylinder(6.2,40,V(0,-114,63),V(0,1,0))
saddle=saddle.cut(bore)
cap=rr(34,11,11.7,63.3,2,0,-93.5).cut(bore)
for i,x in enumerate([-12,12],1):
 saddle=saddle.cut(Part.makeCylinder(1.7,30,V(x,-93.5,50))).cut(Part.makeCylinder(3.2,2.201,V(x,-93.5,53.799)))
 cap=cap.cut(Part.makeCylinder(1.7,20,V(x,-93.5,60))).cut(hexagon(5.8,4,V(x,-93.5,71.4)))
 bolt('ChargeClampBolt'+str(i),V(x,-93.5,56),V(0,0,1),18)
 nut('ChargeClampNut'+str(i),V(x,-93.5,71.4))
lid=lid.cut(front_plate(40.6,28.6,12,-108,63,4.3)).cut(Part.makeCylinder(9.5,20,V(0,-115,63),V(0,1,0)))

for i,(x,z) in enumerate([(x,z) for x in [-14,14] for z in [55,71]],1):
 boss=Part.makeCylinder(5,8.2,V(x,-108,z),V(0,1,0))
 lid=lid.fuse(boss).cut(Part.makeCylinder(1.7,20,V(x,-115,z),V(0,1,0)))
 lid=lid.cut(hexagon(5.8,4.2,V(x,-99.8,z),V(0,-1,0)))
 saddle=saddle.cut(Part.makeCylinder(1.7,10,V(x,-114,z),V(0,1,0))).cut(Part.makeCylinder(3.2,2.001,V(x,-112.001,z),V(0,1,0)))
 bolt('ChargeMountBolt'+str(i),V(x,-110,z),V(0,1,0),10)
 nut('ChargeMountNut'+str(i),V(x,-104,z),V(0,1,0))
put('ChargePort_Insert_D12_placeholder',saddle)
put('ChargeCableClampCap',cap)
put('ChargeSocket_placeholder',Part.makeCylinder(6,26,V(0,-112,63),V(0,1,0)).fuse(Part.makeCylinder(3.5,12,V(0,-86,63),V(0,1,0))),'drawing_proxy')
D.getObject('ChargeSocket_TailSpace').Shape=box(16,20,12,0,-65,57)
for n in ['FrontSwitch_M12_drawing','FrontSwitch_Nut_proxy','SwitchButtonVisual','SwitchHarnessConnectorSpace','SwitchWireSpace']:
 shift(n,dx=65,dy=3,dz=-3)
lid=lid.cut(Part.makeCylinder(6.2,35,V(65,120,81.7997978091967),V(0,-1,0)))
for n in ['FrontSwitch_M12_drawing','FrontSwitch_Nut_proxy']:lid=lid.cut(D.getObject(n).Shape)
# Side openings follow the motor gearboxes. The 85 mm wheels cover these
# necessary ports in side view; there are no eyebrows or separate motor covers.
for side in [-1,1]:
 for yy in [-67,67]:
  port=rr(42,42,22,0,7)
  port.Placement=A.Placement(V(side*82,yy,50.8),A.Rotation(V(0,0,1),V(side,0,0)))
  lid=lid.cut(port).cut(box(22,42,50.8-SEAM+1,side*93,yy,SEAM-1))
report['charge_axis_z']=63
report['charge_clamp_y']=-93.5
report['charge_clamp_depth']=11
remove('D435_90x25x25')  # Superseded by the supplied official camera mesh.
report['motor_cover_removed']=True
report['motor_orientation']='V15 upright, unchanged wheel/output axes'
put('ChassisLower',base,( 'printed'),(.12,.22,.29));put('ChassisLid',lid,'printed',(.82,.88,.91))
report.update(head_drop_mm=HEAD_DROP,roof_z=roof,carrier_floor_z=CARRIER,base_bottom_z=Z,base_top_z=T,lid_seam_z=SEAM,pcb_seat_z=SEAT,joint_screw='4 x M3x10 ISO7380-1',joint_nut='4 x M3 AF5.5 h2.4',lip_height=8,lip_wall=3.5,lip_radial_gap=.6,printed_count=len([o for o in D.Objects if getattr(o,'Role','')=='printed']))
D.recompute();D.Label='NavBot V16.5 — upright motors, Scheme A'
D.saveAs(str(O/'NavBot-V16.5.FCStd'))
(O/'design-parameters.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('SAVED',flush=True)
